# Architecture question for review

## Intended use case

Please assess whether it is technically feasible to let the iPhone bridge a supported BLE
physiological device over local Wi-Fi to the Pi while also driving the existing BLE nRF52840
NeoPixel bracelet as an ambient condition indicator. The goal is mobility: the user should be able
to walk around the house without constantly watching a vitals screen.

The preferred first hardware path is:

```text
BLE physiological device ── BLE ──▶ iPhone app ── local Wi-Fi ──▶ Pi
Pi-derived overall condition ── local Wi-Fi ──▶ iPhone app ── BLE GATT ──▶ nRF52840 NeoPixel bracelet
```

The bracelet is ambient convenience feedback, not the sole emergency detector. A Wi-Fi bracelet is
not the initial target; defer it unless a measured requirement justifies new hardware.

## Questions for ChatGPT

1. Is this architecture technically feasible? The expected answer is “yes” unless a concrete iOS,
   BLE, or hardware limitation makes it infeasible.
2. What latency, jitter, packet-loss, reconnection, and battery behavior should be expected for BLE
   notifications received by an iPhone, forwarded over local Wi-Fi to the Pi, and for Pi state
   mirrored back over BLE to the bracelet?
3. How do iOS foreground, background, locked-screen, force-quit, Bluetooth-central, and local-network
   execution rules affect the guarantee? Distinguish a foreground/active real-time mode from a
   best-effort background mode.
4. How should the Pi-to-iPhone condition messages and iPhone-to-bracelet GATT writes include
   timestamps, monotonic sequence numbers, state generation, and expiry so the bracelet independently
   recognizes stale updates rather than displaying an old reassuring color forever?
5. What transport and authentication should be used over the private LAN? How should frames be bounded,
   sequenced, replay-protected, acknowledged, timed out, and marked stale or unknown?
6. Compare this design with the repository’s accepted architecture. Identify the minimal safe amendment
   needed to permit it without making the iPhone or bracelet authoritative and without weakening the
   Pi’s independent detector, klaxon, and hardware dead-man path.
7. Identify the minimum physical-device experiments for end-to-end latency, jitter, reconnection,
   iOS suspension, bracelet expiry, range, roaming, battery impact, and phone-absent Pi alarm behavior.

## Important current-repository context

The current Stage 7 Apple-client design originally excluded iPhone BLE sessions and rejected permanent
sockets for ordinary sync. Amendment 17 in this snapshot deliberately creates a narrow exception for
an opt-in, bounded BLE mobility relay and a Pi-state-to-BLE-bracelet mirror. It does **not** authorize
legacy-generation BLE collection, local analysis, a second source of truth, or an emergency-alert
path dependent on iOS.

Relevant files include:

- `docs/specs/AMENDMENTS.md`
- `docs/specs/2026-09-22-amendment-17-iphone-ble-mobility-relay.md`
- `docs/design/SPEC-ios-client.md`
- `openspec/changes/ios-client-stage7/proposal.md`
- `openspec/changes/ios-client-stage7/design.md`
- `openspec/changes/ios-client-stage7/tasks.md`
- `clients/apple/`
- `crates/vitals-collectors/`, `crates/vitalsd/`, and `crates/vitals-console/`
- `firmware/`
- `README.md`

The archive contains the current source, tests, OpenSpec contracts, accepted amendments,
API/schema definitions, deployment files, fixtures, documentation, and UI/reference images.
