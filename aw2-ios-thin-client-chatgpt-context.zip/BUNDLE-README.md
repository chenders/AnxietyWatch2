# AnxietyWatch2 ChatGPT context bundle

This bundle is a snapshot of the current working tree for architectural review. The specific
BLE-sensor/iPhone/private-Wi-Fi/Pi/BLE-nRF52840-bracelet question is in `CHATGPT-QUESTION.md`.

It includes source, tests, OpenSpec changes, documentation, schemas, deployment files, fixtures,
and UI/reference images.

## Snapshot

- Created: 2026-09-22T09:35:15Z
- Branch: feature/ios-thin-client
- Git commit: 722da94aacc5292f4ffaa9b7205b048f45ad49fd
- Files in bundle: 2516

## Deliberately excluded

- `.git` history and repository metadata
- Rust/Xcode/SwiftPM build products: `target/`, `*/target/`, `build/`, `*/build/`, `*/.build/`, and DerivedData
- Fuzz generated artifacts and coverage output
- IDE-local workspace state such as `.idea/workspace.xml`
- Object/library binaries and macOS metadata

The source snapshot includes current uncommitted and untracked project files. Amendment 17 is a
planning decision; T-I23 remains unimplemented and requires physical-device evidence.

## Working-tree status at bundle creation

## feature/ios-thin-client
 M .idea/modules.xml
 M README.md
 M api/openapi/client-v1.json
 M clients/apple/AnxietyWatch.xcodeproj/project.pbxproj
 M clients/apple/AnxietyWatch.xcodeproj/xcshareddata/xcschemes/AnxietyWatch.xcscheme
 M clients/apple/AnxietyWatchApp/AnxietyWatchApp.entitlements
 M clients/apple/AnxietyWatchApp/AnxietyWatchApp.swift
 M clients/apple/AnxietyWatchApp/ClientRootView.swift
 M clients/apple/Entitlements.allowlist.json
 M clients/apple/Packages/AWDomain/Sources/AWDomain/JournalFeatures.swift
 M clients/apple/Packages/AWDomain/Tests/AWDomainTests/JournalFeatureTests.swift
 M clients/apple/Packages/AWHealthKit/Sources/AWHealthKit/HealthKitMapper.swift
 M clients/apple/Packages/AWHealthKit/Tests/AWHealthKitTests/HealthKitMapperTests.swift
 M clients/apple/Packages/AWTransport/Sources/AWTransport/SongSearchTransport.swift
 M clients/apple/Packages/AWTransport/Sources/AWTransport/SyncEngine.swift
 M clients/apple/Packages/AWTransport/Tests/AWTransportTests/ClientContractFixtureTests.swift
 M clients/apple/Packages/AWTransport/Tests/AWTransportTests/SongSearchTransportTests.swift
 M crates/vitals-console/Cargo.toml
 M crates/vitals-console/assets/index.html
 M crates/vitals-console/src/client_api.rs
 M crates/vitals-console/src/credentials.rs
 M crates/vitals-console/src/db.rs
 M crates/vitals-console/src/lib.rs
 M crates/vitals-console/src/main.rs
 M crates/vitals-console/src/security.rs
 M db/sqitch.plan
 M deploy/vitals-console.service
 M docs/design/SPEC-admin-console.md
 M docs/design/SPEC-ios-client.md
 M docs/specs/AMENDMENTS.md
 M openspec/changes/admin-console-roadmap/proposal.md
 M openspec/changes/admin-console-roadmap/tasks.md
 M openspec/changes/admin-console-roadmap/traceability.md
 M openspec/changes/ios-client-stage7/design.md
 M openspec/changes/ios-client-stage7/proposal.md
 M openspec/changes/ios-client-stage7/tasks.md
 M openspec/changes/ios-client-stage7/traceability.md
 M scripts/sync-to-pi.sh
 M scripts/verify-ios-client-plan.py
 M scripts/verify-ios-project.sh
 M scripts/verify-openapi.sh
?? .idea/aw2-ios-thin-client.iml
?? .idea/noctule.xml
?? after_clicking_notification.jpg
?? api/fixtures/client-v1/apns-outcome-request.json
?? api/fixtures/client-v1/apns-outcome-response.json
?? api/fixtures/client-v1/apns-registration-request.json
?? api/fixtures/client-v1/apns-registration-response.json
?? artifacts/ios-stage7-apns-evidence.json
?? artifacts/ios-stage7-device-acceptance.json
?? aw2-ios-thin-client-chatgpt-context.zip
?? clients/apple/AnxietyWatchApp/Info.plist
?? clients/apple/Packages/AWTransport/Sources/AWTransport/APNsTransport.swift
?? clients/apple/Packages/AWTransport/Tests/AWTransportTests/APNsTransportTests.swift
?? clients/apple/Tests/AnxietyWatchAppUITests/
?? crates/vitals-console/assets/apns-send.html
?? crates/vitals-console/assets/apns-send.js
?? crates/vitals-console/assets/mobile-enrollment.css
?? crates/vitals-console/assets/mobile-enrollment.html
?? crates/vitals-console/assets/mobile-enrollment.js
?? crates/vitals-console/src/apns.rs
?? db/deploy/apns_delivery.sql
?? db/deploy/apns_idempotency.sql
?? db/deploy/apns_owner_identity.sql
?? db/deploy/apns_registrations.sql
?? db/revert/apns_delivery.sql
?? db/revert/apns_idempotency.sql
?? db/revert/apns_owner_identity.sql
?? db/revert/apns_registrations.sql
?? db/verify/apns_delivery.sql
?? db/verify/apns_idempotency.sql
?? db/verify/apns_owner_identity.sql
?? db/verify/apns_registrations.sql
?? docs/plans/
?? docs/specs/2026-09-18-amendment-16-operator-directed-apns.md
?? docs/specs/2026-09-22-amendment-17-iphone-ble-mobility-relay.md
?? docs/status-updates/2026-09-18-minidude-reboot-execution-plan.md
?? docs/status-updates/2026-09-18-reboot-handoff.md
?? docs/status-updates/2026-09-20-minidude-recovery-evidence.md
?? docs/status-updates/2026-09-20-storage-cleanup-reassessment.md
?? health.jpg
?? healthkit.jpg
?? "journal entry.PNG"
?? newtoday.jpg
?? openspec/changes/pi-prototype-storage-degraded-mode/
?? scripts/verify-ios-apns.sh
?? scripts/verify-remote-apns.sh
?? scrolled.jpg
?? settiings.jpg
?? "song list no album cover.PNG"
?? "song no album cover.PNG"
?? song.PNG
?? "today page.PNG"
?? today.jpg
?? weird.jpg
?? worse.jpg
